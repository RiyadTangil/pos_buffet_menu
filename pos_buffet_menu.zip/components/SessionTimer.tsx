"use client"

import { useSessionTimer } from "@/hooks/useSessionTimer"

export function SessionTimer() {
  useSessionTimer()
  return null
}
